let todosLosEjercicios = [];
let ejerciciosFiltrados = [];
let carrito = [];
let zonaSeleccionadaActual = '';
let patronBiomecanicoActual = 'todos';
let vistaActual = 'frontal';

// 1. Alternancia de Vistas Anatómicas (Frontal / Dorsal)
window.cambiarVistaAnatomica = function (vista) {
    vistaActual = vista;
    const gFrontal = document.getElementById('grupo-frontal');
    const gDorsal = document.getElementById('grupo-dorsal');
    const btnFrontal = document.getElementById('btn-vista-frontal');
    const btnDorsal = document.getElementById('btn-vista-dorsal');

    if (vista === 'frontal') {
        if (gFrontal) gFrontal.style.display = 'inline';
        if (gDorsal) gDorsal.style.display = 'none';
        if (btnFrontal) btnFrontal.className = 'btn-vista-toggle activo';
        if (btnDorsal) btnDorsal.className = 'btn-vista-toggle inactivo';
    } else {
        if (gFrontal) gFrontal.style.display = 'none';
        if (gDorsal) gDorsal.style.display = 'inline';
        if (btnFrontal) btnFrontal.className = 'btn-vista-toggle inactivo';
        if (btnDorsal) btnDorsal.className = 'btn-vista-toggle activo';
    }
};

// 2. Mapa Anatómico SVG
function inicializarEventosMapa() {
    const zonas = document.querySelectorAll('.anatomia-zona');
    const tooltip = document.getElementById('tooltip-anatomico');

    zonas.forEach(zona => {
        zona.addEventListener('click', () => {
            const idZona = zona.getAttribute('data-zona') || '';
            if (zonaSeleccionadaActual === idZona) {
                resetFiltroZona();
            } else {
                zonaSeleccionadaActual = idZona;
                actualizarResaltadoZonas();
                const labelTxt = document.getElementById('txt-zona-seleccionada');
                if (labelTxt) {
                    labelTxt.textContent = idZona.charAt(0).toUpperCase() + idZona.slice(1);
                }
                filtrarYRenderizarEjercicios();
            }
        });

        zona.addEventListener('mousemove', (e) => {
            if (!tooltip) return;
            const nombreZona = zona.getAttribute('data-zona') || 'Músculo';
            const patron = zona.getAttribute('data-patron') || 'General';

            tooltip.style.display = 'block';
            tooltip.style.left = `${e.offsetX + 10}px`;
            tooltip.style.top = `${e.offsetY - 10}px`;
            tooltip.innerHTML = `<strong>${nombreZona.toUpperCase()}</strong><span>Patrón: ${patron}</span>`;
        });

        zona.addEventListener('mouseleave', () => {
            if (tooltip) tooltip.style.display = 'none';
        });
    });
}

window.resetFiltroZona = function () {
    zonaSeleccionadaActual = '';
    const labelTxt = document.getElementById('txt-zona-seleccionada');
    if (labelTxt) labelTxt.textContent = 'Cuerpo Completo';
    actualizarResaltadoZonas();
    filtrarYRenderizarEjercicios();
};

function actualizarResaltadoZonas() {
    document.querySelectorAll('.anatomia-zona').forEach(zona => {
        const idZona = zona.getAttribute('data-zona');
        if (idZona === zonaSeleccionadaActual) {
            zona.classList.add('active');
        } else {
            zona.classList.remove('active');
        }
    });
}

// 3. Filtros Biomecánicos
function inicializarFiltrosBiomecanicos() {
    const pills = document.querySelectorAll('.filtro-biomecanico-pill');
    pills.forEach(pill => {
        pill.addEventListener('click', () => {
            pills.forEach(p => p.className = 'filtro-biomecanico-pill');
            const patron = pill.getAttribute('data-patron');
            patronBiomecanicoActual = patron;

            if (patron === 'todos') pill.classList.add('activo-todos');
            if (patron === 'empuje') pill.classList.add('activo-empuje');
            if (patron === 'traccion') pill.classList.add('activo-traccion');
            if (patron === 'core') pill.classList.add('activo-core');
            if (patron === 'piernas') pill.classList.add('activo-piernas');

            resaltarZonasPorPatron(patron);
            filtrarYRenderizarEjercicios();
        });
    });
}

function resaltarZonasPorPatron(patron) {
    document.querySelectorAll('.anatomia-zona').forEach(zona => {
        const patronZona = zona.getAttribute('data-patron');
        if (patron !== 'todos' && patronZona === patron) {
            zona.classList.add('active-grupo');
        } else {
            zona.classList.remove('active-grupo');
        }
    });
}

// 4. Catálogo de Ejercicios
async function inicializarCatalogo() {
    const loading = document.getElementById('loading-ejercicios');
    const container = document.getElementById('lista-ejercicios-disponibles');
    const noData = document.getElementById('no-ejercicios');

    if (loading) loading.style.display = 'block';
    if (container) container.style.display = 'none';
    if (noData) noData.style.display = 'none';

    try {
        todosLosEjercicios = await api.getEjercicios();
        if (todosLosEjercicios && todosLosEjercicios.results) {
            todosLosEjercicios = todosLosEjercicios.results;
        } else if (!Array.isArray(todosLosEjercicios)) {
            todosLosEjercicios = [];
        }
        filtrarYRenderizarEjercicios();
    } catch (error) {
        console.error('Error cargando ejercicios:', error);
        if (noData) {
            noData.style.display = 'block';
            noData.querySelector('p').textContent = `Error al cargar catálogo: ${error.message}`;
        }
    } finally {
        if (loading) loading.style.display = 'none';
    }
}

function filtrarYRenderizarEjercicios() {
    const inputBuscar = document.getElementById('input-buscar-ejercicio');
    const termino = inputBuscar ? inputBuscar.value.trim().toLowerCase() : '';
    const container = document.getElementById('lista-ejercicios-disponibles');
    const noData = document.getElementById('no-ejercicios');

    ejerciciosFiltrados = todosLosEjercicios.filter(item => {
        const nombre = (item.nombre || item.titulo || '').toLowerCase();
        const grupo = (item.zona_cuerpo || item.grupo_muscular || '').toLowerCase();
        const patron = (item.patron_movimiento || item.patron || '').toLowerCase();

        const coincideTexto = !termino || nombre.includes(termino) || grupo.includes(termino);
        const coincideZona = !zonaSeleccionadaActual || grupo.includes(zonaSeleccionadaActual.toLowerCase());
        const coincidePatron = patronBiomecanicoActual === 'todos' || patron.includes(patronBiomecanicoActual);

        return coincideTexto && coincideZona && coincidePatron;
    });

    if (!container || !noData) return;

    if (ejerciciosFiltrados.length === 0) {
        container.style.display = 'none';
        noData.style.display = 'block';
        return;
    }

    noData.style.display = 'none';
    container.style.display = 'flex';
    container.innerHTML = '';

    ejerciciosFiltrados.forEach(ej => {
        const div = document.createElement('div');
        div.className = 'ejercicio-item-card';

        const nombre = ej.nombre || ej.titulo || 'Ejercicio';
        const zona = ej.zona_cuerpo || ej.grupo_muscular || 'General';

        div.innerHTML = `
            <div>
                <strong style="color: var(--azul-900); font-size: 0.92rem;">${nombre}</strong>
                <div style="font-size: 0.78rem; color: var(--gris-600); margin-top: 3px;">
                    <span class="badge badge-neutro">${zona}</span>
                </div>
            </div>
            <button type="button" class="btn btn-secondary btn-sm" onclick="agregarAlCarrito(${ej.id})">
                <i class='bx bx-plus'></i> Añadir
            </button>
        `;
        container.appendChild(div);
    });
}

// 5. Carrito de Prescripción
window.agregarAlCarrito = function (idEjercicio) {
    const ejercicio = todosLosEjercicios.find(e => e.id === idEjercicio);
    if (!ejercicio) return;

    const existente = carrito.find(item => item.ejercicio.id === idEjercicio);
    if (existente) {
        existente.series += 1;
    } else {
        carrito.push({
            ejercicio: ejercicio,
            series: 3,
            repeticiones: 12,
            descanso: 60
        });
    }

    renderizarCarrito();
};

window.eliminarDelCarrito = function (index) {
    carrito.splice(index, 1);
    renderizarCarrito();
};

window.actualizarDosificacion = function (index, campo, valor) {
    if (carrito[index]) {
        carrito[index][campo] = parseInt(valor, 10) || 0;
    }
};

function renderizarCarrito() {
    const contenedor = document.getElementById('carrito-items-container');
    const badgeTotal = document.getElementById('badge-total-items');
    const btnSubmit = document.getElementById('btn-confirmar-pauta');

    if (badgeTotal) badgeTotal.textContent = `${carrito.length} Ejercicios`;
    if (btnSubmit) btnSubmit.disabled = (carrito.length === 0);

    if (!contenedor) return;

    if (carrito.length === 0) {
        contenedor.innerHTML = `
            <div class="empty-state" id="carrito-vacio-msg" style="padding: 16px;">
                <p style="margin: 0; font-size: 0.85rem;">El carrito está vacío. Haz clic en "Añadir" en los ejercicios que desees prescribir.</p>
            </div>
        `;
        return;
    }

    contenedor.innerHTML = '';
    carrito.forEach((item, index) => {
        const div = document.createElement('div');
        div.className = 'carrito-item-card';
        const nombre = item.ejercicio.nombre || item.ejercicio.titulo || 'Ejercicio';

        div.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                <strong style="font-size: 0.85rem; color: var(--azul-900);">${nombre}</strong>
                <button type="button" onclick="eliminarDelCarrito(${index})" style="background: none; border: none; color: var(--rojo-500); cursor: pointer;" title="Quitar">
                    <i class='bx bx-trash'></i>
                </button>
            </div>
            <div class="carrito-item-inputs">
                <div class="field" style="margin: 0;">
                    <label style="font-size: 0.7rem;">Series</label>
                    <input type="number" min="1" value="${item.series}" onchange="actualizarDosificacion(${index}, 'series', this.value)" style="padding: 4px 6px; font-size: 0.8rem;">
                </div>
                <div class="field" style="margin: 0;">
                    <label style="font-size: 0.7rem;">Reps / Seg</label>
                    <input type="number" min="1" value="${item.repeticiones}" onchange="actualizarDosificacion(${index}, 'repeticiones', this.value)" style="padding: 4px 6px; font-size: 0.8rem;">
                </div>
                <div class="field" style="margin: 0;">
                    <label style="font-size: 0.7rem;">Descanso(s)</label>
                    <input type="number" min="0" step="5" value="${item.descanso}" onchange="actualizarDosificacion(${index}, 'descanso', this.value)" style="padding: 4px 6px; font-size: 0.8rem;">
                </div>
            </div>
        `;
        contenedor.appendChild(div);
    });
}

// 6. Selector de Pacientes y Detección de Parámetro URL (?paciente=ID)
async function cargarSelectorPacientes() {
    const select = document.getElementById('select-paciente-pauta');
    if (!select) return;

    try {
        let pacientes = await api.getMisPacientes();
        if (pacientes && pacientes.results) pacientes = pacientes.results;
        if (!Array.isArray(pacientes)) pacientes = pacientes ? [pacientes] : [];

        select.innerHTML = '<option value="">-- Seleccionar Paciente --</option>';

        const params = new URLSearchParams(window.location.search);
        const pacienteUrlParam = params.get('paciente');

        pacientes.forEach(p => {
            const opt = document.createElement('option');
            // Priorizamos user_id del serializador de perfil o p.user si viene hidratado
            const userId = p.user_id || ((p.user && typeof p.user === 'object') ? p.user.id : (p.user || p.id));
            opt.value = userId;

            const nombre = p.nombre_completo || (p.user && typeof p.user === 'object' ? `${p.user.first_name} ${p.user.last_name}`.trim() : '') || 'Paciente';
            opt.textContent = `${nombre} (${p.rut || 'Sin RUT'})`;

            // Auto-seleccionar si coincide con el parámetro de la URL
            if (pacienteUrlParam && (String(userId) === String(pacienteUrlParam) || String(p.id) === String(pacienteUrlParam))) {
                opt.selected = true;
            }

            select.appendChild(opt);
        });

    } catch (error) {
        console.error('Error al cargar selector de pacientes:', error);
    }
}

// 7. Envío y Creación de la Pauta hacia PautaCreateSerializer
function inicializarFormularioPauta() {
    const form = document.getElementById('form-guardar-pauta');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const selectPaciente = document.getElementById('select-paciente-pauta');
        const inputNombre = document.getElementById('pauta-nombre');
        const btnSubmit = document.getElementById('btn-confirmar-pauta');

        const pacienteId = selectPaciente ? selectPaciente.value : '';
        const titulo = inputNombre ? inputNombre.value.trim() : '';

        if (!pacienteId) {
            alert('Por favor, selecciona un paciente en el menú desplegable superior.');
            if (selectPaciente) selectPaciente.focus();
            return;
        }

        if (!titulo) {
            alert('Por favor, ingresa un título o diagnóstico para la pauta.');
            if (inputNombre) inputNombre.focus();
            return;
        }

        if (carrito.length === 0) {
            alert('Debes añadir al menos un ejercicio a la pauta.');
            return;
        }

        // Formato exacto requerido por PautaCreateSerializer
        const payload = {
            paciente: parseInt(pacienteId, 10),
            titulo: titulo,
            ejercicios_detalle: carrito.map(item => ({
                ejercicio: item.ejercicio.id,
                series: parseInt(item.series, 10) || 3,
                repeticiones: parseInt(item.repeticiones, 10) || 10,
                tiempo_descanso_segundos: parseInt(item.descanso, 10) || 60
            }))
        };

        btnSubmit.disabled = true;
        btnSubmit.innerHTML = "<i class='bx bx-loader-alt bx-spin'></i> Guardando...";

        try {
            await api.crearPauta(payload);
            alert('¡Pauta clínica creada y asignada con éxito!');
            window.location.href = 'pautas.html';
        } catch (error) {
            console.error('Error al guardar pauta:', error);
            alert(`Error al guardar: ${error.message || 'Comprueba los datos ingresados.'}`);
        } finally {
            btnSubmit.disabled = false;
            btnSubmit.innerHTML = "<i class='bx bx-save'></i> Guardar y Asignar Pauta";
        }
    });
}

// Inicialización global
document.addEventListener('DOMContentLoaded', () => {
    if (typeof api !== 'undefined' && !api.isAuthenticated()) {
        window.location.href = 'index.html';
        return;
    }

    inicializarEventosMapa();
    inicializarFiltrosBiomecanicos();
    inicializarCatalogo();
    cargarSelectorPacientes();
    inicializarFormularioPauta();

    const inputBuscar = document.getElementById('input-buscar-ejercicio');
    if (inputBuscar) {
        inputBuscar.addEventListener('input', filtrarYRenderizarEjercicios);
    }
});