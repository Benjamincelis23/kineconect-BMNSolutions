import re
import secrets
import threading
from django.contrib.auth.models import User
from django.core.mail import send_mail
from rest_framework import serializers
from .models import Perfil, Ejercicio, Pauta, PautaEjercicio, RegistroFeedback


def validar_rut_chileno(rut: str) -> str:
    """
    Limpia y valida formato básico y dígito verificador (Módulo 11) de RUT chileno.
    Retorna el RUT en formato XXXXXXXX-Y en mayúsculas.
    """
    rut_limpio = rut.replace('.', '').replace(' ', '').strip().upper()
    
    if not re.match(r'^\d{7,8}-[\dK]$', rut_limpio):
        raise serializers.ValidationError(
            "El formato del RUT es inválido. Use el formato sin puntos y con guión (ej: 12345678-9 o 11700900-K)."
        )
    
    cuerpo, dv = rut_limpio.split('-')
    
    # Validación Módulo 11
    suma = 0
    multiplicador = 2
    for d in reversed(cuerpo):
        suma += int(d) * multiplicador
        multiplicador = 2 if multiplicador == 7 else multiplicador + 1
        
    resto = suma % 11
    dv_esperado = 11 - resto
    
    if dv_esperado == 11:
        dv_calculado = '0'
    elif dv_esperado == 10:
        dv_calculado = 'K'
    else:
        dv_calculado = str(dv_esperado)
        
    if dv != dv_calculado:
        raise serializers.ValidationError(
            f"El dígito verificador del RUT es incorrecto. Para {cuerpo} corresponde el dígito {dv_calculado}."
        )
        
    return rut_limpio


class PacienteRegistroSerializer(serializers.ModelSerializer):
    """Serializador para HU-001: Registro y vinculación de Paciente por el Kinesiólogo."""
    first_name = serializers.CharField(max_length=150, required=True)
    last_name = serializers.CharField(max_length=150, required=True)
    email = serializers.EmailField(required=False, allow_blank=True)
    rut = serializers.CharField(max_length=12, required=True)

    class Meta:
        model = User
        fields = ('id', 'first_name', 'last_name', 'email', 'rut')

    def validate_rut(self, value):
        rut_valido = validar_rut_chileno(value)
        if Perfil.objects.filter(rut=rut_valido).exists():
            raise serializers.ValidationError("Este RUT ya se encuentra registrado en el sistema.")
        return rut_valido

    def create(self, validated_data): 
        rut = validated_data.pop('rut')
        kinesiologo = self.context['request'].user
        
        # Username basado en el RUT limpio para login simplificado (ej: 11700900K)
        username = rut.replace('-', '').replace('.', '').upper()
        
        # Clave segura generada de forma nativa
        password_temporal = secrets.token_urlsafe(9)
        
        user = User.objects.create_user(
            username=username,
            first_name=validated_data.get('first_name', ''),
            last_name=validated_data.get('last_name', ''),
            email=validated_data.get('email', ''),
            password=password_temporal 
        )

        # update_or_create para evitar colisiones si existe signal post_save creando el perfil
        Perfil.objects.update_or_create(
            user=user,
            defaults={
                'rut': rut,
                'rol': 'PACIENTE',
                'kinesiologo_asignado': kinesiologo
            }
        )

        # Enviar correo al paciente en segundo plano
        if user.email:
            email_thread = threading.Thread(
                target=send_mail,
                args=(
                    'Bienvenido a Kineconect - Tu cuenta',
                    f'Hola {user.first_name}, el kinesiólogo te ha registrado. Tu usuario es: {username} y tu contraseña temporal es: {password_temporal}. Por favor, cámbiala al iniciar sesión.',
                    'noreply@kineconect.cl',
                    [user.email]
                ),
                kwargs={'fail_silently': True}
            )
            email_thread.start()

        return user


class PerfilSerializer(serializers.ModelSerializer):
    nombre_completo = serializers.CharField(source='user.get_full_name', read_only=True)
    email = serializers.EmailField(source='user.email', read_only=True)
    user_id = serializers.IntegerField(source='user.id', read_only=True)

    class Meta:
        model = Perfil
        fields = ('id', 'user_id', 'rut', 'rol', 'nombre_completo', 'email', 'kinesiologo_asignado')


class EjercicioSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ejercicio
        fields = ('id', 'nombre', 'descripcion', 'zona_cuerpo', 'video_url', 'imagen', 'gif_url')


# ==========================================
# SERIALIZADORES PARA LA API REST DE PAUTAS
# ==========================================

class PautaEjercicioSerializer(serializers.ModelSerializer):
    """Serializador para el Detalle de la Pauta (Ejercicios específicos)"""
    ejercicio_info = EjercicioSerializer(source='ejercicio', read_only=True)

    class Meta:
        model = PautaEjercicio
        fields = ('ejercicio', 'ejercicio_info', 'series', 'repeticiones', 'tiempo_descanso_segundos')


class PautaCreateSerializer(serializers.ModelSerializer):
    """Serializador transaccional para crear la Cabecera y el Detalle en un solo POST"""
    ejercicios_detalle = PautaEjercicioSerializer(many=True)

    class Meta:
        model = Pauta
        fields = ('paciente', 'titulo', 'ejercicios_detalle')

    def validate_paciente(self, value):
        if not hasattr(value, 'perfil') or value.perfil.rol != 'PACIENTE':
            raise serializers.ValidationError("El usuario seleccionado no tiene rol de PACIENTE.")
        return value

    def create(self, validated_data):
        ejercicios_data = validated_data.pop('ejercicios_detalle')
        validated_data['kinesiologo'] = self.context['request'].user
        
        # 1. Crear Cabecera
        pauta = Pauta.objects.create(**validated_data)
        
        # 2. Crear Detalles usando Bulk Create
        PautaEjercicio.objects.bulk_create([
            PautaEjercicio(pauta=pauta, **detalle) for detalle in ejercicios_data
        ])
        
        return pauta


class PautaReadSerializer(serializers.ModelSerializer):
    """Serializador para consultar pautas en GET (App Móvil y Web)"""
    ejercicios_detalle = PautaEjercicioSerializer(many=True, read_only=True)
    kinesiologo_nombre = serializers.CharField(source='kinesiologo.get_full_name', read_only=True)
    paciente_nombre = serializers.CharField(source='paciente.get_full_name', read_only=True)

    class Meta:
        model = Pauta
        fields = ('id', 'titulo', 'kinesiologo_nombre', 'paciente_nombre', 'activo', 'creado_en', 'ejercicios_detalle')


class RegistroFeedbackSerializer(serializers.ModelSerializer):
    """Serializador para pantalla de feedback y registro EVA"""
    class Meta:
        model = RegistroFeedback
        fields = ('id', 'pauta', 'completado', 'escala_dolor', 'comentario', 'fecha_ejecucion')
        read_only_fields = ('fecha_ejecucion',)